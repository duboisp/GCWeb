---
name: Documentation
about: Signalez une lacune dans la documentation
title: 'Documentation - [`nom de la composante`]'
labels: 'documentation'
assignees: ''
---

