---
name: Question
about: Ask for clarification or guidance
title: 'Question - [`component name`]'
labels: 'question'
assignees: ''
---
